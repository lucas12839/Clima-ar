# Casos históricos ClimaAR

Paquete preparado a partir de las imágenes originales aportadas.

## Casos
- `2025-02-02_granizo`: 16 imágenes.
- `2025-03-07_inundacion`: 29 imágenes.

Los PNG fueron renombrados con fecha/hora UTC derivada del encabezado visible de cada radar. Se conservaron todos los cuadros disponibles y **no se inventaron cuadros faltantes**.

Cada caso incluye `manifest.json` y `secuencia.csv` para que ClimaAR pueda consumir la secuencia de forma reproducible.

La información meteorológica histórica todavía debe incorporarse en una etapa separada; este paquete contiene únicamente los radares históricos y su índice temporal.
